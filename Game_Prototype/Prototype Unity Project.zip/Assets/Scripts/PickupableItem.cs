using UnityEngine;

namespace DefaultNamespace
{
    public class PickupableItem : MonoBehaviour
    {
        private void OnCollisionEnter2D(Collision2D other)
        {
            if (other.gameObject.GetComponent<PlayerController>() != null)
            {
                transform.parent = other.gameObject.transform;
            }
        }
    }
}