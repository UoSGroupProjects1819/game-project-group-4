﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreUI : MonoBehaviour
{
	private GameManager gameManager;
	private Image progressImage;

	void Start()
	{
		gameManager = FindObjectOfType<GameManager>();
		progressImage = GetComponent<Image>();
	}
	
	void Update ()
	{
		progressImage.fillAmount = (gameManager.scoreRef.GetHighestPlayerScore() / gameManager.scoreRef.winningScore);
	}
}
