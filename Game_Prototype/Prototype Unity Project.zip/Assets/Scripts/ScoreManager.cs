﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class ScoreManager : MonoBehaviour
{
	public float winningScore = 500;
	
	private float[] _scores = {
		0, 0, 0, 0
	};

	public void Update()
	{
		if (GetHighestPlayerScore() >= winningScore)
		{
			FindObjectOfType<GameManager>().EndGame(_scores.ToList().IndexOf(GetHighestPlayerScore()));
		}
	}

	public void IncreaseScore(int playerNum, int ammount)
	{
		_scores[playerNum] += ammount;
	}

	public float GetHighestPlayerScore()
	{
		return _scores.Max();
	}
}
