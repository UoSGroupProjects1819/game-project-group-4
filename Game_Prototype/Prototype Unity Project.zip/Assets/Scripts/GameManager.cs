﻿using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public ScoreManager scoreRef;

    void Start()
    {
        scoreRef = FindObjectOfType<ScoreManager>();
    }

    public void EndGame(int playerID)
    {
        switch (playerID)
        {
            case 0:
                Debug.Log("Player One Won!");
                break;
            case 1:
                Debug.Log("Player Two Won!");
                break;
            case 2:
                Debug.Log("Player Three Won!");
                break;
        }

        EditorApplication.isPlaying = false;
        Application.Quit();
    }
}
