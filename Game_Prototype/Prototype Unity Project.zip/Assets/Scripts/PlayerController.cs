﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{

	[Range(0,3)]
	public int playerNumber;
	
	
	[HideInInspector] public bool jump = false;
	public float moveForce = 365f;
	public float maxSpeed = 5f;
	public float jumpForce = 1000f;
	public Transform groundCheck;


	private bool grounded = false;

	[HideInInspector] public bool facingRight = true;
	
	private Rigidbody2D _rigidBody;
	private float _y = 0f;
	public float speed = 5;

	void Update()
	{
		if (Input.GetKeyDown(KeyCode.W) && playerNumber == 0) jump = true;
		if (Input.GetKeyDown(KeyCode.S) && playerNumber == 1) jump = true;
		if (Input.GetKeyDown(KeyCode.X) && playerNumber == 2) jump = true;
		if (Input.GetKeyDown(KeyCode.UpArrow) && playerNumber == 3) jump = true;
	}
	
	void Flip()
	{
		facingRight = !facingRight;
		Vector3 theScale = transform.localScale;
		theScale.x *= -1;
		transform.localScale = theScale;
	}

	void Start ()
	{
		_rigidBody = GetComponent<Rigidbody2D>();
	}

	//on collision with a item
/*	private void OnTriggerEnter2D(Collider2D other)
	{
		//Check if the triggered object is a Item
		if (other.gameObject.GetComponent<FastItem>())
		{
			if (!GetComponent<FastItem>() || !GetComponent<SlowItem>() || !GetComponent<NormalItem>())
			{
				other.gameObject.transform.parent = transform;
			}
		}
		if (other.gameObject.GetComponent<SlowItem>())
		{
			if (!GetComponent<FastItem>() || !GetComponent<SlowItem>() || !GetComponent<NormalItem>())
			{
				other.gameObject.transform.parent = transform;
			}
		}
		if (other.gameObject.GetComponent<NormalItem>())
		{
			if (!GetComponent<FastItem>() || !GetComponent<SlowItem>() || !GetComponent<NormalItem>())
			{
				other.gameObject.transform.parent = transform;
			}
		}
	}

	//on collision with another player
	private void OnCollisionEnter2D(Collision2D other)
	{
		//check the other item is a player
		if (other.gameObject.GetComponent<PlayerController>())
		{
			//get the item
			if (other.gameObject.GetComponentInChildren<FastItem>())
			{
				other.gameObject.GetComponentInChildren<FastItem>().transform.parent = transform;
			} else 
			if (other.gameObject.GetComponentInChildren<SlowItem>())
			{
				other.gameObject.GetComponentInChildren<SlowItem>().transform.parent = transform;
			} else
			if (other.gameObject.GetComponentInChildren<NormalItem>())
			{
				other.gameObject.GetComponentInChildren<NormalItem>().transform.parent = transform;
			}
		}
	}*/

	void ProcessMovement2()
	{
		float h = 0;

		switch (playerNumber)
		{
			case 0: h = Input.GetAxis("P1");
				break;
			case 1: h = Input.GetAxis("P2");
				break;
			case 2: h = Input.GetAxis("P3");
				break;
			case 3: h = Input.GetAxis("P4");
				break;
		}

		if (h * _rigidBody.velocity.x < maxSpeed)
			_rigidBody.AddForce(Vector2.right * h * moveForce);

		if (Mathf.Abs (_rigidBody.velocity.x) > maxSpeed)
			_rigidBody.velocity = new Vector2(Mathf.Sign (_rigidBody.velocity.x) * maxSpeed, _rigidBody.velocity.y);

		if (h > 0 && !facingRight)
			Flip ();
		else if (h < 0 && facingRight)
			Flip ();

		if (jump)
		{
			_rigidBody.AddForce(new Vector2(0f, jumpForce), ForceMode2D.Impulse);
			jump = false;
		}
	}

	void ProcessMovement()
	{
		switch (playerNumber)
		{
			case 0:
			{
				if (Input.GetKey(KeyCode.W)) _y = 1f;
				else _y = 0f;
				Vector3 movement = new Vector3 (Input.GetAxis("P1"), 0.0f, 0.0f);
				_rigidBody.AddForce(new Vector2(0, _y), ForceMode2D.Impulse);
				_rigidBody.velocity = movement * speed;
			}
				break;
			case 1:
			{
				if (Input.GetKey(KeyCode.S)) _y = 1f;
				else _y = 0f;
				Vector3 movement = new Vector3 (Input.GetAxis("P2"), 0.0f, 0.0f);
				_rigidBody.AddForce(new Vector2(0, _y), ForceMode2D.Impulse);
				_rigidBody.velocity = movement * speed;
			}
				break;
			case 2:
			{
				if (Input.GetKey(KeyCode.X)) _y = 1f;
				else _y = 0f;
				Vector3 movement = new Vector3 (Input.GetAxis("P3"), 0.0f, 0.0f);
				_rigidBody.AddForce(new Vector2(0, _y), ForceMode2D.Impulse);
				_rigidBody.velocity = movement * speed;
			}
				break;
			case 3:
			{
				if (Input.GetKey(KeyCode.UpArrow)) _y = 1f;
				else _y = 0f;
				Vector3 movement = new Vector3 (Input.GetAxis("P4"), 0.0f, 0.0f);
				_rigidBody.AddForce(new Vector2(0, _y), ForceMode2D.Impulse);
				_rigidBody.velocity = movement * speed;
			}
				break;
		}
	}
	
	void FixedUpdate () {
		ProcessMovement2();
	}
}
