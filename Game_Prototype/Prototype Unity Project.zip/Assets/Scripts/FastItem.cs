﻿using System.Collections;
using System.Collections.Generic;
using DefaultNamespace;
using UnityEngine;

public class FastItem : PickupableItem {
	private GameManager gameManager;

	void Start()
	{
		gameManager = FindObjectOfType<GameManager>();
	}

	void Update ()
	{
		if (GetComponentInParent<PlayerController>())
		{
			transform.localScale = new Vector3(0.25f, 0.25f, 0.25f);
			GetComponentInParent<PlayerController>().speed = 10;
			gameManager.scoreRef.IncreaseScore(GetComponentInParent<PlayerController>().playerNumber, 15);
		}
	}
}
