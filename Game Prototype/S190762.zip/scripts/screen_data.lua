local M = {}

M.screenX = 1280
M.screenY = 720

return M